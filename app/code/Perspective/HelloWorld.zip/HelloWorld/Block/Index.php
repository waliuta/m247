<?php
namespace Perspective\HelloWorld\Block;

class Index extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Framework\View\Element\Template\Context $context)
	{
		parent::__construct($context);
	}

    public function sayHello()
	{
		return __('150 Learn Magento 2 Block Layout');
	}

}
