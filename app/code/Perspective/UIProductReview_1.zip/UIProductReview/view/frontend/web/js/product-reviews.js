define([
    'uiComponent',
    'ko',
    'jquery',
    'mage/url'
], function (Component, ko, $, urlBuilder) {
    return Component.extend({
        defaults: {
            template: 'Perspective_UIProductReview/product-reviews',
            reviews: ko.observableArray([]),
            productId: null,
        },

        initialize: function () {
            this._super();
            console.log('Product Reviews Component Initialized...');
            this.loadReviews();
        },

        loadReviews: function () {
            var self = this;
            console.log('loadReview thisproductID...'+ this.productId);
            if (!this.productId) {
                console.error('Product ID is not provided...');
                return;
            }
            if (this.reviews.length > 0) {
                console.log('Reviews loaded:', this.reviews);
            }
        },
    });
});
