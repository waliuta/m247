<?php
Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Perspective_RepositoryExcersize',
    __DIR__
);
